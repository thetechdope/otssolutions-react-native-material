export const Route = {
    Login : "LoginScreen",
    Register : "Register",
    Profile: "Profile"
}